﻿#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<memory.h>
using namespace std;

int main()
{

    FILE *fpRead = NULL,*fpWrite = NULL;
    int Run_time[40];
    int Com_quan[40];
    int n = 40;
    char filename[128];
    char outfilename[128];
    char line[1024];
    char tmpstrTime[128] = "# type version cycles";
    char tmpstrComup[128] = "# type  quantity  ";
    ifstream infiles("inputfile.dat");

    if(infiles==NULL){
        cout<<"can't open inputfile.dat !"<<endl;
        exit(-1);
    }
   while(infiles){
        if(infiles.eof()){
            cout<<"Done!\n";
            break;
        }
        infiles.getline(filename,128);
        //cout<<filename<<endl;
        strcpy(outfilename,filename);
        strcat(outfilename,".out");

        ifstream infile(filename);
        if(infile==NULL){
            cout<<"can't open "<<filename<<endl;
            exit(-1);
        }
        if(infile!=NULL){
            int task_Count = 0;
            fpWrite = fopen(outfilename,"a");
            infile.getline(line,1024);
            while(strcmp(line,tmpstrTime)!=0){
                infile.getline(line,1024);
            }
            int type_Id,version,cycles;
            for(int i=0;i<n;++i){
                infile>>type_Id>>version>>cycles;
                Run_time[type_Id] = cycles;
            }
            while(strcmp(line,tmpstrComup)!=0){
                infile.getline(line,1024);
            }
            int quantity;
            for(int i=0;i<n;++i){
                infile>>type_Id>>quantity;
                Com_quan[type_Id] = quantity;
            }
            while(line[0]!='@'){
                infile.getline(line,1024);
            }
            infile.getline(line,1024);
            infile.getline(line,1024);
            char task[10],task_Num[20],type[5];
            if(strlen(line)==0){
                infile.getline(line,1024);
                while(strlen(line)!=0){
                    task_Count++;
                    infile.getline(line,1024);
                }
                fprintf(fpWrite,"%d %d\n",2,task_Count);
                for(int i=0;i<task_Count;++i){
                    fprintf(fpWrite,"%d ",Run_time[i]);
                }fprintf(fpWrite,"\n\n");
            }
            int **comu = new int*[task_Count];
            for(int i=0;i<task_Count;++i){
                comu[i] = new int[task_Count];
            }

            //memset(comu,0,sizeof(int)*task_Count*task_Count);
            for(int i=0;i<task_Count;++i){
                for(int j=0;j<task_Count;++j){
                    comu[i][j] = 0;
                }
            }
            char ARC[4],arc_num[10],From[5],task1[10],To[3],task2[10],tmp[4];
            int from,to;
            if(strlen(line)==0){
                infile>>ARC>>arc_num>>From>>task1>>To>>task2>>type>>type_Id;
                while(strcmp(ARC,"ARC")==0){
                    //cout<<ARC<<arc_num<<From<<task1<<To<<task2<<type<<type_Id<<endl;
                    sscanf(task1,"%[^_]_%d",tmp,&from);
                    sscanf(task2,"%[^_]_%d",tmp,&to);
                    //cout<<from<<"->"<<to<<endl;
                    //cout<<task1<<" "<<task2<<endl;
                    comu[from][to] = Com_quan[type_Id];
                    infile>>ARC>>arc_num>>From>>task1>>To>>task2>>type>>type_Id;
                }
            }
            for(int i=0;i<task_Count;++i){
                for(int j=0;j<task_Count;++j){
                    fprintf(fpWrite,"%d ",comu[i][j]);
                }fprintf(fpWrite,"\n");
            }
            fclose(fpWrite);
            infile.close();
        }
   }
    infiles.close();
    return 0;
}
